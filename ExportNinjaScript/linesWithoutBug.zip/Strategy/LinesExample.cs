#region Using declarations
using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using NinjaTrader.Adapter;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui.Chart;
using IOrder = NinjaTrader.Cbi.IOrder;

#endregion

// This namespace holds all strategies and is required. Do not change it.
namespace NinjaTrader.Strategy
{
    /// <summary>
    /// Example of lines working of Danial. That scrpt what you send to me and  what workig is just so simple. That it takes 1-2 hours to made it
    /// </summary>
    [Description("Example of lines working of Danial. That scrpt what you send to me and  what workig is just so simple. That it takes 1-2 hours to made it")]
    public class LinesExample : Strategy
    {
	    enum StrategyState
	    {
		    NotActive,
			Enter,
			Exit,
	    }
        #region Variables
        // Wizard generated variables
        private int myInput0 = 1; // Default setting for MyInput0
        // User defined variables (add any user defined variables below)
		private int _target = 40; // Default setting for Target
		private int _stopLoss = 20; // Default setting for StopLoss
	    private bool isLong;
	    private bool isLines;
	    private bool isTrading;
	    private ToolStrip ToolStripMy;
	    private ToolStripButton ButtonsLong;
	    private ToolStripButton ButtonShort;
	    private ToolStripButton ButtonHorizontal;
	    private ToolStripButton ButtonActivate;
	    private ToolStripSeparator _toolStripSeparator;
	    private IRay EntryRay;
	    private IRay StopRay;
	    private IRay ProfitTargetRay;
	    private StrategyState _strategyState = StrategyState.NotActive;


	    private IOrder _entryOrder;
	    #endregion

	    protected override void OnStartUp()
	    {
		    base.OnStartUp();
		    this.Enabled = true;
		    CreateButtonsOnTop();
			ChartControl.ChartPanel.MouseUp += ChartPanelOnMouseUp;

	    }

	    private void ChartPanelOnMouseUp(object sender, MouseEventArgs mouseEventArgs)
	    {
				
	    }

	    protected override void OnTermination()
	    {
		    base.OnTermination();
		    ChartControl.ChartPanel.MouseUp -= ChartPanelOnMouseUp;
		    RemoveButtons();
			GC.Collect();
	    }

	    private void RemoveButtons()
	    {
			ToolStripMy.Items.Remove(_toolStripSeparator);
			ToolStripMy.Items.Remove(ButtonsLong);
			ToolStripMy.Items.Remove(ButtonShort);
			ToolStripMy.Items.Remove(ButtonHorizontal);
			ToolStripMy.Items.Remove(ButtonActivate);
		    _toolStripSeparator = null;
		    ButtonsLong = null;
		    ButtonShort = null;
		    ButtonHorizontal = null;
		    ButtonActivate = null;
	    }

	    private void CreateButtonsOnTop()
	    {
		    Control[] tsControls = ChartControl.Controls.Find("tsrTool", false);
		    if (tsControls != null && tsControls.Length > 0)
		    {
				//Getting toolStrip and add the separator
			    ToolStripMy = (ToolStrip) tsControls[0];
			    _toolStripSeparator = new ToolStripSeparator();
			    ToolStripMy.Items.Add(_toolStripSeparator);
			
				//Creating the buttons	
				//Long
				ButtonsLong= new ToolStripButton("Long");
			    ButtonsLong.BackColor = Color.Red;
				ButtonsLong.Click += ButtonsLongOnClick;

				//Short 
			    ButtonShort = new ToolStripButton("Short");
			    ButtonShort.BackColor = Color.Green;
				ButtonShort.Click += ButtonShortOnClick;

				//Horizontal
				ButtonHorizontal = new ToolStripButton("Horizontal");
			    ButtonHorizontal.BackColor = Color.Blue;
				ButtonHorizontal.Click += ButtonHorizontalOnClick;

				//Activate
				ButtonActivate = new ToolStripButton("Activate");
			    ButtonActivate.BackColor = Color.Aqua;
				ButtonActivate.Click += ButtonActivateOnClick;

				//Now we add those buttons to the top
				ToolStripMy.Items.AddRange(new ToolStripItem[] { ButtonsLong,ButtonShort,ButtonHorizontal,ButtonActivate});

		    }
	    }

	    protected override void Initialize()
	    {

		    CalculateOnBarClose = false;
		    Enabled = true; 
						if (_target > 0)
				SetProfitTarget(CalculationMode.Ticks, _target);

			if (_stopLoss > 0)
				SetStopLoss(CalculationMode.Ticks, _stopLoss);
		    base.Initialize();
	    }

	    private void ButtonActivateOnClick(object sender, EventArgs eventArgs)
	    {
			_strategyState = StrategyState.Enter;
	    }
	    public double RayPrice(IRay ray)

	    {
		    //So how much step per bar we got here
		    double oneBarDistance = (ray.Anchor1Y - ray.Anchor2Y)/(ray.Anchor1BarsAgo - ray.Anchor2BarsAgo);
		    //Now how add the count of those steps to over lest price and then return 
		    double rayPrice = (-oneBarDistance*ray.Anchor2BarsAgo) + ray.Anchor2Y;
		    return Instrument.MasterInstrument.Round2TickSize(rayPrice);
	    }

	    public void SetRayToRayPrice(IRay ray)
	    {
		    double rayPrice = RayPrice(ray);
		    ray.Anchor1Y = rayPrice;
		    ray.Anchor2Y = rayPrice;
	    }

	    private void ButtonHorizontalOnClick(object sender, EventArgs eventArgs)
	    {
			SetRayToRayPrice(EntryRay);
			SetRayToRayPrice(StopRay);
			SetRayToRayPrice(ProfitTargetRay);
			UpdateChart();
	    }

	    private void ButtonShortOnClick(object sender, EventArgs eventArgs)
	    {
		    isLong = false;
			CreateLines(isLong);
	    }

	    private void ButtonsLongOnClick(object sender, EventArgs eventArgs)
	    {
			isLong = true;
		    CreateLines(isLong);
	    }

	    public double Distance;
	    private Color EnterColor = Color.Blue;
	    private Color StopColor = Color.Red;
	    private Color TpColor = Color.Green;

	    private void CreateLines(bool isLong)
	    {
			double min = GetMinPrice();
			double max = GetMaxPrice();
			Distance = Math.Round((max - min)/2,4);
		    double distance = Distance;

		    if (isLong)
			    distance *= -1;
		    double d =Close[0] +(distance)/2;
		    EntryRay = DrawRay("Enter", false, 5, d -Math.Round(distance*.3,4), -1, Close[0] - Math.Round(distance*.3,4), EnterColor, DashStyle.Solid, 2);
			StopRay = DrawRay("Stop", false, 5, d+ distance, -1, Close[0] + distance, StopColor, DashStyle.Dash, 2);
			ProfitTargetRay = DrawRay("TakeProfit", false, 5, d- distance, -1, Close[0] -distance, TpColor, DashStyle.Dash, 2);
		    EntryRay.Locked = false;
		    StopRay.Locked = false;
		    ProfitTargetRay.Locked = false;
		    UpdateChart();
		    //Now unblocking those lines for drawing
	    }

	    private void UpdateChart()
	    {
		    ChartControl.Size = new Size(ChartControl.Size.Width, ChartControl.Size.Height + 1);
		    ChartControl.Update();
		    ChartControl.Size = new Size(ChartControl.Size.Width, ChartControl.Size.Height - 1);
	    }

	    private double GetMaxPrice()
		{
			int length = Math.Min(20, High.Count);
			double result = Close[0];
			for (int i = 0; i < length; i++)
				result = Math.Max(result, High[i]);
			return result;
		}

		private double GetMinPrice()
		{
			int length = Math.Min(20, Low.Count);
			double result = Close[0];
			for (int i = 0; i < length; i++)
				result = Math.Min(result, Low[i]);

			return result;
		}
	    protected override void OnPositionUpdate(IPosition position)
	    {
			if (_strategyState==StrategyState.Enter && Position.MarketPosition != MarketPosition.Flat)
		    {
			    _strategyState = StrategyState.Exit;
				RemoveDrawObject(EntryRay);
		    }
		    else if (position.MarketPosition == MarketPosition.Flat&&_strategyState==StrategyState.Exit)
		    {
			    RemoveDrawObject(ProfitTargetRay);
				RemoveDrawObject(StopRay);
			    _strategyState = StrategyState.NotActive;
		    }
	    }

	    /// <summary>
        /// Called on each bar update event (incoming tick)
        /// </summary>
        protected override void OnBarUpdate()
        {
			//Switching to exit
		    if (_strategyState==StrategyState.Enter)
		    {
				if(EntryRay==null)
					return;
			    if (isLong)
					_entryOrder = EnterLongStop(0, true, DefaultQuantity, RayPrice(EntryRay), "LongStop");
			    else
					_entryOrder = EnterShortStop(0, true, DefaultQuantity, RayPrice(EntryRay), "ShortStop");
		    }
		    else if (_strategyState==StrategyState.Exit)
		    {
				if(ProfitTargetRay==null||StopRay==null)
					return;

				    SetProfitTarget(CalculationMode.Price, RayPrice(ProfitTargetRay) + TickSize);
				    SetStopLoss(CalculationMode.Price, RayPrice(StopRay) - TickSize);
		    }
        }

        #region Properties
        [Description("")]
        [GridCategory("Parameters")]
        public int MyInput0
        {
            get { return myInput0; }
            set { myInput0 = Math.Max(1, value); }
        }
        #endregion
    }
}

#region Wizard settings, neither change nor remove
/*@
<?xml version="1.0" encoding="utf-16"?>
<NinjaTrader>
  <Name>LinesExample</Name>
  <CalculateOnBarClose>True</CalculateOnBarClose>
  <Description>Example of lines working of Danial. That scrpt what you send to me and  what workig is just so simple. That it takes 1-2 hours to made it</Description>
  <Parameters>
    <Parameter>
      <Default1>
      </Default1>
      <Default2>1</Default2>
      <Default3>
      </Default3>
      <Description>
      </Description>
      <Minimum>1</Minimum>
      <Name>MyInput0</Name>
      <Type>int</Type>
    </Parameter>
  </Parameters>
  <State>
    <CurrentState>
      <StrategyWizardState xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
        <Name>Flat</Name>
        <Sets />
        <StopTargets />
      </StrategyWizardState>
    </CurrentState>
  </State>
</NinjaTrader>
@*/
#endregion