﻿using System;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using NinjaTrader.Cbi;
using Timer = System.Timers.Timer;

namespace NinjaTrader.Strategy
{
	
	public partial class AccountInfo : Form
	{
		public class UpdatingData
		{
			private string _buyingPower;
			private string _cashValue;
			private string _realizedProfit;
			private Image _chartImage;

			public UpdatingData(string buyingPower, string cashValue, string realizedProfit, Image chartImage)
			{
				_buyingPower = buyingPower;
				_cashValue = cashValue;
				_realizedProfit = realizedProfit;
				_chartImage = chartImage;
			}

			public string BuyingPower
			{
				get { return _buyingPower; }
			}

			public string CashValue
			{
				get { return _cashValue; }
			}

			public string RealizedProfit
			{
				get { return _realizedProfit; }
			}

			public Image ChartImage
			{
				get { return _chartImage; }
			}
		}

		private ChartSlopeTrader _CST { get;  set; }

		private Timer formUpdateTimer;
		private UpdatingData _updatingData;
		private ulong ticks =0;

		private const double interval = 50;

		public AccountInfo(ChartSlopeTrader cst)
		{
			InitializeComponent();
			_CST = cst;
			_width = pictureBox1.Width;
			_height = pictureBox1.Height;
			GetData();
			UpdateData();
			formUpdateTimer = new Timer(interval);
			formUpdateTimer.Elapsed += FormUpdateTimer_Elapsed;
			formUpdateTimer.Start();
		}

		private bool first;
		private int _width;
		private int _height;

		private void FormUpdateTimer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
		{
			try
			{
				GettingSettingData();
			}
			catch (Exception exception)
			{
				MessageBox.Show(exception.Message+exception.StackTrace);
			}
		}

		private void GettingSettingData()
		{
			ticks++;
			if (ticks%2 == 0)
				GetData();
			else
				UpdateData();
		}

		private void GetData()
		{
		_updatingData = new UpdatingData(RoundAndString(_CST.GetAccountValue(AccountItem.BuyingPower)),
						RoundAndString(_CST.GetAccountValue(AccountItem.CashValue)),
						RoundAndString(_CST.GetAccountValue(AccountItem.RealizedProfitLoss)),
						ResizeImage(_CST.GetChartPictureFast(), _width, _height));
		}

		private void UpdateData()
		{
			lock (_updatingData)
			{
				textBoxBuyingPower.Text = _updatingData.BuyingPower;
				textBoxCashValue.Text = _updatingData.CashValue;
				textBoxRealizedProfit.Text = _updatingData.RealizedProfit;
				pictureBox1.Image = _updatingData.ChartImage;
				
			}
		}

		private Image ResizeImage(Bitmap image, int width, int height)
		{
			return new Bitmap(image,width,height);
		}

		private string RoundAndString(double value)
		{
			return Math.Round(value, 2).ToString();
		}

		private void _buttonUpdateClick(object sender, EventArgs e)
		{
		}

		private void _buttonCloseClick(object sender, EventArgs e)
		{
			Dispose();
		}
	}
}
