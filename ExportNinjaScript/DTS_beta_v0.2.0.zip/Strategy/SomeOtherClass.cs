using System.Windows.Forms;

namespace NinjaTrader.Strategy
{
	public class SomeOtherClass
	{
		private Button _buttonClosePosition;
	}
}