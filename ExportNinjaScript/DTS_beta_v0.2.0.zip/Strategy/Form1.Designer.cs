﻿namespace NinjaTrader.Strategy
{
	partial class AccountInfo
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.tabControl1 = new System.Windows.Forms.TabControl();
			this.tabPage1 = new System.Windows.Forms.TabPage();
			this.textBoxRealizedProfit = new System.Windows.Forms.TextBox();
			this.textBoxCashValue = new System.Windows.Forms.TextBox();
			this.textBoxBuyingPower = new System.Windows.Forms.TextBox();
			this.labelRealizedProfitLoss = new System.Windows.Forms.Label();
			this.labelCashValue = new System.Windows.Forms.Label();
			this.labelBuyingPower = new System.Windows.Forms.Label();
			this.tabPage2 = new System.Windows.Forms.TabPage();
			this.tabPage3 = new System.Windows.Forms.TabPage();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.tabPage4 = new System.Windows.Forms.TabPage();
			this.tabControl1.SuspendLayout();
			this.tabPage1.SuspendLayout();
			this.tabPage3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.SuspendLayout();
			// 
			// tabControl1
			// 
			this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.tabControl1.Controls.Add(this.tabPage1);
			this.tabControl1.Controls.Add(this.tabPage2);
			this.tabControl1.Controls.Add(this.tabPage3);
			this.tabControl1.Controls.Add(this.tabPage4);
			this.tabControl1.Location = new System.Drawing.Point(1, -1);
			this.tabControl1.Multiline = true;
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.Padding = new System.Drawing.Point(0, 0);
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.Size = new System.Drawing.Size(658, 356);
			this.tabControl1.TabIndex = 0;
			// 
			// tabPage1
			// 
			this.tabPage1.BackColor = System.Drawing.SystemColors.Control;
			this.tabPage1.Controls.Add(this.textBoxRealizedProfit);
			this.tabPage1.Controls.Add(this.textBoxCashValue);
			this.tabPage1.Controls.Add(this.textBoxBuyingPower);
			this.tabPage1.Controls.Add(this.labelRealizedProfitLoss);
			this.tabPage1.Controls.Add(this.labelCashValue);
			this.tabPage1.Controls.Add(this.labelBuyingPower);
			this.tabPage1.Location = new System.Drawing.Point(4, 22);
			this.tabPage1.Name = "tabPage1";
			this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage1.Size = new System.Drawing.Size(650, 330);
			this.tabPage1.TabIndex = 0;
			this.tabPage1.Text = "Info";
			// 
			// textBoxRealizedProfit
			// 
			this.textBoxRealizedProfit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.textBoxRealizedProfit.Location = new System.Drawing.Point(11, 80);
			this.textBoxRealizedProfit.Name = "textBoxRealizedProfit";
			this.textBoxRealizedProfit.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.textBoxRealizedProfit.Size = new System.Drawing.Size(100, 26);
			this.textBoxRealizedProfit.TabIndex = 5;
			this.textBoxRealizedProfit.Text = "0";
			// 
			// textBoxCashValue
			// 
			this.textBoxCashValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.textBoxCashValue.Location = new System.Drawing.Point(11, 43);
			this.textBoxCashValue.Name = "textBoxCashValue";
			this.textBoxCashValue.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.textBoxCashValue.Size = new System.Drawing.Size(100, 26);
			this.textBoxCashValue.TabIndex = 4;
			this.textBoxCashValue.Text = "0";
			// 
			// textBoxBuyingPower
			// 
			this.textBoxBuyingPower.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.textBoxBuyingPower.Location = new System.Drawing.Point(11, 6);
			this.textBoxBuyingPower.Name = "textBoxBuyingPower";
			this.textBoxBuyingPower.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.textBoxBuyingPower.Size = new System.Drawing.Size(100, 26);
			this.textBoxBuyingPower.TabIndex = 3;
			this.textBoxBuyingPower.Text = "0";
			// 
			// labelRealizedProfitLoss
			// 
			this.labelRealizedProfitLoss.AutoSize = true;
			this.labelRealizedProfitLoss.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.labelRealizedProfitLoss.Location = new System.Drawing.Point(117, 77);
			this.labelRealizedProfitLoss.Name = "labelRealizedProfitLoss";
			this.labelRealizedProfitLoss.Size = new System.Drawing.Size(227, 29);
			this.labelRealizedProfitLoss.TabIndex = 2;
			this.labelRealizedProfitLoss.Text = "Realized Profit Loss";
			// 
			// labelCashValue
			// 
			this.labelCashValue.AutoSize = true;
			this.labelCashValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.labelCashValue.Location = new System.Drawing.Point(117, 40);
			this.labelCashValue.Name = "labelCashValue";
			this.labelCashValue.Size = new System.Drawing.Size(135, 29);
			this.labelCashValue.TabIndex = 1;
			this.labelCashValue.Text = "Cash Value";
			// 
			// labelBuyingPower
			// 
			this.labelBuyingPower.AutoSize = true;
			this.labelBuyingPower.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.labelBuyingPower.Location = new System.Drawing.Point(117, 3);
			this.labelBuyingPower.Name = "labelBuyingPower";
			this.labelBuyingPower.Size = new System.Drawing.Size(162, 29);
			this.labelBuyingPower.TabIndex = 0;
			this.labelBuyingPower.Text = "Buying Power";
			// 
			// tabPage2
			// 
			this.tabPage2.Location = new System.Drawing.Point(4, 22);
			this.tabPage2.Name = "tabPage2";
			this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage2.Size = new System.Drawing.Size(1106, 656);
			this.tabPage2.TabIndex = 1;
			this.tabPage2.Text = "E-Mail Setting";
			this.tabPage2.UseVisualStyleBackColor = true;
			// 
			// tabPage3
			// 
			this.tabPage3.Controls.Add(this.pictureBox1);
			this.tabPage3.Location = new System.Drawing.Point(4, 22);
			this.tabPage3.Name = "tabPage3";
			this.tabPage3.Size = new System.Drawing.Size(1106, 656);
			this.tabPage3.TabIndex = 2;
			this.tabPage3.Text = "Chart ";
			this.tabPage3.UseVisualStyleBackColor = true;
			// 
			// pictureBox1
			// 
			this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.pictureBox1.Location = new System.Drawing.Point(0, 0);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(1106, 656);
			this.pictureBox1.TabIndex = 0;
			this.pictureBox1.TabStop = false;
			// 
			// tabPage4
			// 
			this.tabPage4.Location = new System.Drawing.Point(4, 22);
			this.tabPage4.Name = "tabPage4";
			this.tabPage4.Size = new System.Drawing.Size(1106, 656);
			this.tabPage4.TabIndex = 3;
			this.tabPage4.Text = "Money managment";
			this.tabPage4.UseVisualStyleBackColor = true;
			// 
			// AccountInfo
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.AutoSize = true;
			this.ClientSize = new System.Drawing.Size(661, 354);
			this.Controls.Add(this.tabControl1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
			this.Name = "AccountInfo";
			this.Text = "Account Info";
			this.tabControl1.ResumeLayout(false);
			this.tabPage1.ResumeLayout(false);
			this.tabPage1.PerformLayout();
			this.tabPage3.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.TabControl tabControl1;
		private System.Windows.Forms.TabPage tabPage1;
		private System.Windows.Forms.TabPage tabPage2;
		private System.Windows.Forms.Label labelBuyingPower;
		private System.Windows.Forms.TextBox textBoxRealizedProfit;
		private System.Windows.Forms.TextBox textBoxCashValue;
		private System.Windows.Forms.TextBox textBoxBuyingPower;
		private System.Windows.Forms.Label labelRealizedProfitLoss;
		private System.Windows.Forms.Label labelCashValue;
		private System.Windows.Forms.TabPage tabPage3;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.TabPage tabPage4;
	}
}

